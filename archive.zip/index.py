import os
from os import path
import shutil
from shutil import make_archive
from zipfile import ZipFile

#check to make sure a file exists before we try to do anyhting with it
if path.exists('chapter1.txt'):
    # get the file path
    src = path.realpath('chapter1.txt')

    # create a destination/backup file
    dst = src + '.bak' #this takes the original path and adds a .bak (for backup) to the end of it
    shutil.copy(src, dst) # this copies the first path into the second

    #rename a file
    os.rename('chapter1.txt.bak', 'chapter2.txt')

    # create a zip files
    (root, file) = path.split(src) # returns a tuple with 2 values, the parent directory of the file and the file name
    shutil.make_archive('archive', 'zip', root) #(name of new file, format of file, directory to archive)

    # create a custom zip file
    # with creates a local scope that makes it easier to work with objects
    # newzip will be assigned the instantiaton of the ZipFile class
    # we can then use varaibles inside the scope of the with block to better manage the context of actions
    with ZipFile('testzip.zip', 'w') as newzip:
        # add specific files to the archive
        newzip.write('chapter1.txt')
        newzip.write('chapter2.txt')
