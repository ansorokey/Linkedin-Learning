# Linkedin-Learning
My notes and reviews for the courses taken through LinkedIn Learning
